# MiniMax H3 Audio Drive node

This minimal ComfyUI custom-node package contains only the
`VRGDG_MiniMaxH3AudioDrive` node required by MiniMax H3 Studio's digital-human
workflow.

Source: <https://github.com/vrgamegirl19/comfyui-vrgamedevgirl>

Upstream commit: `de65ec552f2552e90170d5572b2c53d544bedd7e`

Install the extracted `comfyui-minimax-h3-audio-drive` directory under
`ComfyUI/custom_nodes/`, then restart ComfyUI. The node uses the `torch` and
`torchaudio` packages already required by ComfyUI.

The source remains licensed under the GNU Affero General Public License v3.0.
See `LICENSE` for the upstream notice.
